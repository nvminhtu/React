<a name="1.0.0"></a>
# [1.0.0](https://github.com/reactstrap/component-template/compare/0.2.0...v1.0.0) (2017-01-28)


### Features

* **lint:** add eslint to test setup ([4756833](https://github.com/reactstrap/component-template/commit/4756833))



<a name="0.2.0"></a>
# 0.2.0 (2016-09-25)


### Features

* **HelloWorld:** add hello world component ([a2da070](https://github.com/reactstrap/component-template/commit/a2da070))



